#!/bin/bash

CHR=$1 #Total number of chromosomes of the reference (Human)
REF_NAME=$2 #Name of the new reference
NEW_REF=$3  #Total number of chromosomes of the new reference
G_DB=$4 #Path to the GENOMES_DB
PARAL=$5
CORES=$6
OOC=$7
FASTMAP=$8

CHR1=1
PWD=`pwd`
TOOLS=$PWD/bin

[ ! -d $PWD/tmp ] && mkdir -p $PWD/tmp
[ ! -d $PWD/HCEs_changed_names ] && mkdir -p $PWD/HCEs_changed_names
[ ! -d $PWD/HCE_FASTA_coords ] && mkdir -p $PWD/HCE_FASTA_coords
[ ! -d $PWD/hceVsRef ] && mkdir -p $PWD/hceVsRef
[ ! -d $PWD/HCEs_sizes ] && mkdir -p $PWD/HCEs_sizes
[ ! -d $PWD/hceVsRef_filtered ] && mkdir -p $PWD/hceVsRef_filtered
[ ! -d $PWD/Ref_chroms ] && mkdir -p $PWD/Ref_chroms
[ ! -d $PWD/intermediate_coords ] && mkdir -p $PWD/intermediate_coords
[ ! -d $PWD/intermediate_coords_2 ] && mkdir -p $PWD/intermediate_coords_2
[ ! -d $PWD/FINAL_coords ] && mkdir -p $PWD/FINAL_coords
[ ! -d $PWD/FINAL_FASTA ] && mkdir -p $PWD/FINAL_FASTA

P_HCEs=$PWD/P_HCEs
HCEs_changed_names=$PWD/HCEs_changed_names
P_FASTA=$PWD/HCE_FASTA_coords
hceVsRef=$PWD/hceVsRef
SIZES=$PWD/HCEs_sizes
hceVsRef_F=$PWD/hceVsRef_filtered
REF_CHROMS=$PWD/Ref_chroms
INTERMEDIATE=$PWD/intermediate_coords
INTERMEDIATE_2=$PWD/intermediate_coords_2
FINAL_COORD=$PWD/FINAL_coords
FINAL_FASTA=$PWD/FINAL_FASTA


echo "Preparing the new Reference genome...."
for i in $(seq $CHR1 $NEW_REF)
	do
	$TOOLS/twoBitToFa $G_DB/REFERENCE/chr$i.2bit $PWD/tmp/chr$i.fa
	done

for j in  $(seq $CHR1 $NEW_REF) 
        do
        cat $PWD/tmp/chr$j.fa >> $PWD/tmp/$REF_NAME.fa
        done

if [ ! -f $G_DB/REFERENCE/hg38.fa ]
	then
	echo "The old reference (hg38) is in .2bit format, so it should be converted into fasta (hg38.fa)"
	echo "Preparing the old reference genome...."
	$TOOLS/twoBitToFa $G_DB/REFERENCE/hg38.2bit $G_DB/REFERENCE/hg38.fa
fi

echo "Sorting the predicted elements..."
for n in $(seq $CHR1 $CHR)
	do
	sort -n -k2,2 $P_HCEs/most_conserved_chr$n.bed > $P_HCEs/most_conserved.chr$n.sorted.bed
	done

if [ "$FASTMAP" -eq "1" ]
then
echo "--fastMap works with HCE <= 5Kbp. Splitting the larger HCE..."
for CHR_NUM in $(seq $CHR1 $CHR)
        do
        $TOOLS/HCEs_splitting.sh $CHR_NUM 
	done
rm $P_HCEs/*.txt
else
echo "--fastMap not enabled. No need of splitting the large HCE..."
fi

echo "Extracting the fasta sequences for the predicted HCEs..."
for p in $(seq $CHR1 $CHR)
	do
	$TOOLS/fastaFromBed -fi $G_DB/REFERENCE/hg38.fa -bed $P_HCEs/most_conserved.chr$p.sorted.bed -fo $P_FASTA/most_conserved_chr$p.fas -name
	done
for p in $(seq $CHR1 $CHR)
        do
        $TOOLS/trimFa.pl  $P_FASTA/most_conserved_chr$p.fas > $P_FASTA/most_conserved_chr$p.fa
        done
#######ooc
if [ $OOC -eq 1 ]
then
if [ ! -f $TOOLS/$REF_NAME.11.ooc ]
then
        echo "Lets generate an 11.ooc file..."
        RSIZE=`$TOOLS/faSize $PWD/tmp/$REF_NAME.fa | awk 'NR==1{print $5}'`
        HgRATIO=`awk 'BEGIN{printf "%.6f\n", '"$RSIZE"' / 2897310462 * 1024}'`
        INTNUM=`awk 'BEGIN{printf "%.0f\n", '"$HgRATIO"'}'`
        ROUND1=`awk 'BEGIN{printf "%.0f\n", '"$INTNUM"' / 50}'`
        ROUND2=`awk 'BEGIN{printf "%.0f\n", '"$ROUND1"' * 50}'`
        $TOOLS/blat $PWD/tmp/$REF_NAME.fa /dev/null /dev/null -tileSize=11 -makeOoc=$TOOLS/$REF_NAME.11.ooc -repMatch=$ROUND2
         echo "done!!!"
else
	echo "11.ooc file exist, continue with the mapping phase..."
fi
fi
###########
echo "Mapping the HCEs up to the new reference..."
if [ $PARAL -eq 1 ] && [ $OOC -eq 1 ] && [ $FASTMAP -eq 1 ]
then
	echo "Mapping phase is running on $CORES threads with -fastMap and -ooc parameters on"
	for q in $(seq $CHR1 $CHR)
	do
		$TOOLS/pblat -threads=$CORES -fastMap -ooc=$TOOLS/${REF_NAME}.11.ooc $PWD/tmp/$REF_NAME.fa $PWD/HCE_FASTA_coords/most_conserved_chr$q.fa -out=blast9 $hceVsRef/$q.out
	sleep 5
        done
fi
if [ $PARAL -eq 1 ] && [ $OOC -eq 0 ] && [ $FASTMAP -eq 0 ]
then
	echo "Mapping phase is running on $CORES threads with none of the BLAT parameters"
        for q in $(seq $CHR1 $CHR)
        do
                $TOOLS/pblat -threads=$CORES $PWD/tmp/$REF_NAME.fa $PWD/HCE_FASTA_coords/most_conserved_chr$q.fa -out=blast9 $hceVsRef/$q.out
        sleep 5
        done
fi
if [ $PARAL -eq 1 ] && [ $OOC -eq 0 ] && [ $FASTMAP -eq 1 ]
then
	echo "Mapping phase is running on $CORES threads with -fastMap parameter on"
        for q in $(seq $CHR1 $CHR)
        do
                $TOOLS/pblat -threads=$CORES -fastMap $PWD/tmp/$REF_NAME.fa $PWD/HCE_FASTA_coords/most_conserved_chr$q.fa -out=blast9 $hceVsRef/$q.out
        sleep 5
        done
fi

if [ $PARAL -eq 1 ] && [ $OOC -eq 1 ] && [ $FASTMAP -eq 0 ]
then
	echo "Mapping phase is running on $CORES threads with -ooc parameter on"
        for q in $(seq $CHR1 $CHR)
        do
                $TOOLS/pblat -threads=$CORES -ooc=$TOOLS/${REF_NAME}.11.ooc $PWD/tmp/$REF_NAME.fa $PWD/HCE_FASTA_coords/most_conserved_chr$q.fa -out=blast9 $hceVsRef/$q.out
        sleep 5
        done
fi
if [ $PARAL -eq 0 ] && [ $OOC -eq 1 ] && [ $FASTMAP -eq 1 ]
then
	echo "Mapping phase is running on a single core  with -fastMap and -ooc parameters on"
        for q in $(seq $CHR1 $CHR)
        do
                $TOOLS/blat -fastMap -ooc=$TOOLS/${REF_NAME}.11.ooc $PWD/tmp/$REF_NAME.fa $PWD/HCE_FASTA_coords/most_conserved_chr$q.fa -out=blast9 $hceVsRef/$q.out
        sleep 5
        done
fi
if [ $PARAL -eq 0 ] && [ $OOC -eq 0 ] && [ $FASTMAP -eq 1 ]
then
	 echo "Mapping phase is running on a single core  with -fastMap parameters on"
        for q in $(seq $CHR1 $CHR)
        do
                $TOOLS/blat -fastMap $PWD/tmp/$REF_NAME.fa $PWD/HCE_FASTA_coords/most_conserved_chr$q.fa -out=blast9 $hceVsRef/$q.out
        sleep 5
        done
fi
if [ $PARAL -eq 0 ] && [ $OOC -eq 1 ] && [ $FASTMAP -eq 0 ]
then
	 echo "Mapping phase is running on a single core  with -ooc parameters on (recomented)"
        for q in $(seq $CHR1 $CHR)
        do
                $TOOLS/blat -ooc=$TOOLS/${REF_NAME}.11.ooc $PWD/tmp/$REF_NAME.fa $PWD/HCE_FASTA_coords/most_conserved_chr$q.fa -out=blast9 $hceVsRef/$q.out
        sleep 5
        done
fi
if [ $PARAL -eq 0 ] && [ $OOC -eq 0 ] && [ $FASTMAP -eq 0 ]
then
	 echo "Mapping phase is running on a single core with none of the BLAT parameteres (recomented)"
        for q in $(seq $CHR1 $CHR)
        do
                $TOOLS/blat $PWD/tmp/$REF_NAME.fa $PWD/HCE_FASTA_coords/most_conserved_chr$q.fa -out=blast9 $hceVsRef/$q.out
        sleep 5
        done
fi

echo "Calculating HCEs sizes..."
for w in $(seq $CHR1 $CHR)
	do
	$TOOLS/faSize -detailed $P_FASTA/most_conserved_chr$w.fa > $SIZES/most_conserved_chr$w.sizes
	done

echo "Filtering the alignments..."
for x in $(seq $CHR1 $CHR)
	do
	$TOOLS/Blat_filtering_V2.pl $hceVsRef/$x.out $SIZES/most_conserved_chr$x.sizes > $hceVsRef_F/$x.out
	done

echo "Sorting..."
for y in $(seq $CHR1 $CHR)
	do
	sort -u -k1,1 $hceVsRef_F/$y.out > $hceVsRef_F/$y.unique.out
	done

for c in $(seq $CHR1 $CHR)
	do
	cat $hceVsRef_F/$c.unique.out >> $hceVsRef_F/all.unique.out
	done

echo "Separating the chromosomes..."
for k in $(seq $CHR1 $NEW_REF)
	do 
	awk '$2 == "'"chr$k"'" { print $0 }' $hceVsRef_F/all.unique.out > $REF_CHROMS/chr$k.out
	done

echo "Tranforming in bed format..."
for l in $(seq $CHR1 $NEW_REF)
        do
	$TOOLS/change_ref_out_1.pl $REF_CHROMS/chr$l.out $l > $INTERMEDIATE/chr$l.out
	done
echo "Sorting..."
for b in $(seq $CHR1 $NEW_REF)
        do
	sort -n -k2,2 $INTERMEDIATE/chr$b.out > $INTERMEDIATE/chr$b.sorted.out
	done
echo "Final stage of Reference changing...."
for m in $(seq $CHR1 $NEW_REF)
        do
	$TOOLS/change_ref_out_2.pl $INTERMEDIATE/chr$m.sorted.out  $m > $FINAL_COORD/most_conserved.chr$m.bed
	done


echo "Extracting the final fasta sequences for the predicted HCEs with the new reference..."
for z in $(seq $CHR1 $NEW_REF)
        do
        $TOOLS/fastaFromBed -fi $PWD/tmp/$REF_NAME.fa -bed $FINAL_COORD/most_conserved.chr$z.bed -fo $FINAL_FASTA/most_conserved_chr$z.fas -name
        done
for p in $(seq $CHR1 $CHR)
        do
        $TOOLS/trimFa.pl  $FINAL_FASTA/most_conserved_chr$z.fas > $FINAL_FASTA/most_conserved_chr$z.fa
        done
