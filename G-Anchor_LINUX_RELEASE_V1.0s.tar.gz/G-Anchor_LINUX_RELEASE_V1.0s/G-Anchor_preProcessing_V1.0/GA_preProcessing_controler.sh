#!/bin/bash

PWD=`pwd`
IN=$PWD/INPUT

if [ $# -lt 1 ]
then
	echo "Wellcome to HCE preprocessing phase:"
	echo "By using this pipeline you can change the reference genome of the predicted HCE"
	echo "Use -h or --help option to see G-Anchor_preProcessing' features..."
	exit 1
fi

####################
#Interactive mode function
function interactive {
        echo "Give the total number of chromosomes of the old reference: "
	read CHR1
	echo "Give the name of the new reference: "
        read NAME
        echo "Give the total number of chromosomes of the new reference: "
	read CHR2
	echo "Give the absolute path for the two genomes: "
        read GENOME_DB
	echo "Do you want to run the alignment part in parallel? (y/n)"
        read PARAL

        if [ $PARAL == "y"  ]
        then
                FLAGP=1
        else
                FLAGP=0
        fi

        if [ $PARAL == "y"  ]
        then
                echo "Give the number of the threads"
                read CORES
                R=$CORES
        else
                R=1
        fi	
	if [ $CORES -eq $CORES 2>/dev/null ]
        then
                C=$CORES
        else
                echo "Wrong input. It should be an int"
                exit
        fi
        echo "Do you want to use the -ooc parameter? (y/n)"
        read OOC
        if [ $OOC == "y"  ]
        then
                FLAGOOC=1
        else
                FLAGOOC=0
        fi

        echo "Do you want to use the -fastMap parameter? (y/n)"
        read FM
        if [ $FM == "y"  ]
        then
                FM=1
        else
                FM=0
        fi
	echo "The preprocessing pipeline will project the HCE from human reference genome to $NAME genome..."
	./G-Anchor_preProcessing.sh $CHR1 $NAME $CHR2 $GENOME_DB $FLAGP $R $FLAGOOC $FM &>logFile
        sleep 5
	rm -r HCEs_changed_names HCE_FASTA_coords HCEs_sizes hceVsRef_filtered hceVsRef intermediate_coords intermediate_coords_2 Ref_chroms tmp
	echo "G-Anchor's preprocessing stage is finished!"
	echo "Your new HCE fasta sequences (calculated based on the new reference) are in FINAL_FASTA/ folder. The HCE coordinates (.bed format) are in HCE_FASTA_coords/ folder"
	echo "Don't forget to check the logFile"
	exit 1
}
#EOF
##################
###################
while test $# -gt 0; do
        case "$1" in
                -h|--help)
			echo "---------------------------------------------------------------------------------------------------------------------------------"
                        echo "G-Anchor's preprocessing pipeline: Changing the reference that the HCE are predicted"
			echo "---------------------------------------------------------------------------------------------------------------------------------"
                        echo " "
                        echo "-h, --help			Show brief help"
			echo "Basic parameteres:"
                        echo "-a				Total number of original reference's chromosomes"
                        echo "-n, --name=<string>		Name of the new chosen reference"
			echo "-b                              Total number of NEW reference's chromosomes"
			echo "-g, --Gpath=<absolut path>      The absolute path for the GENOMES_DB folder where the two genomes are in .2bit format"
			echo " "
			echo "options:"
			echo "-p <int>			Number of threds for multicore run"
			echo "--fastMap			Use fastMap option"
			echo "--ooc				Use ooc option"
			echo "-r				Run G-Anchor's preprocessing stage in interactive mode"
                        echo " "
			echo "Command sample:"
			echo "./G-Anchor_preProcessing.sh -a 22 -b 29 -n BosTau7 -g /Users/Usename/G-Anchor/INPUT/GENOME_DB"
			echo "---------------------------------------------------------------------------------------------------------------------------------"
			exit 0
                        ;;
		-a)
			shift
			if test $# -gt 0; then
				export START=$1
			else
                                echo "no total number of original reference's chromosomes specified"
                                exit 1
                        fi
                        shift
                        ;;
		-b) 
			shift
                        if test $# -gt 0; then
                                export END=$1
                        else
                                echo "no total number of NEW reference's chromosomes specified"
                                exit 1
                        fi
                        shift
                        ;;
		-n)
			shift
                        if test $# -gt 0; then
                                export NAME=$1
                        else
                                echo "no name for new reference genome specified"
                                exit 1
                        fi
                        shift
                        ;;
		--name*)
                        export NAME=`echo $1 | sed -e 's/^[^=]*=//g'`
                        shift
                        ;;
		 -p)
                        shift
                        if test $# -gt 0; then
                                export CPU=$1
			fi
                        shift
                        ;;
		-g)
                        shift
                        if test $# -gt 0; then
                                export GENOME_DB=$1
                        fi
                        shift
                        ;;
		--Gpath*)
                        export GENOME_DB=`echo $1 | sed -e 's/^[^=]*=//g'`
                        shift
                        ;;
		 --fastMap*)
			FM=1
			shift
                        ;;
		--ooc*)
			OOC=1
                        shift
                        ;;
		-r)
			if [ "$1" == "-r" ]; then
  				interactive;
			fi
                        shift
                        ;;
		-*)	
                        if test $# -gt 0; then
                	echo "Unrecognized argument"
			exit 1
			fi
			shift
			;;
                *)
                        break
                        ;;
        esac
done


if [ -z "$START" ]; then
 	echo "no total number of original reference's chromosomes specified"
  	exit 1
else
	CHR1=$START 
fi
if [ -z "$END" ]; then
        echo "no total number of NEW reference's chromosomes specified"
        exit 1
else
	CHR2=$END
fi
if [ -z "$NAME" ]; then
        echo "no name for new reference genome specified"
        exit 1
else 
	GENOME=$NAME
fi
if [ -z "$GENOME_DB" ]; then
        echo "no absolute path for the genome's db (GENOME_DB) specified"
        exit 1
else
        GENOME=$GENOME_DB
fi

if [ -z "$CPU" ]; then
	FLAGP=0
        R=1
else
	FLAGP=1
	R=$CPU
fi
if [ -z "$FM" ]; then
	FASTMAP=0
else 
	FASTMAP=1
fi
if [ -z "$OOC" ]; then
        OOC1=0
else
	OOC1=1
fi


#############
echo "The preprocessing pipeline will project the HCE from human reference genome to $NAME genome..."
 ./G-Anchor_preProcessing.sh $CHR1 $NAME $CHR2 $GENOME $FLAGP $R $OOC1 $FASTMAP &>logFile
 sleep 5
 rm -r HCEs_changed_names HCE_FASTA_coords HCEs_sizes hceVsRef_filtered hceVsRef intermediate_coords intermediate_coords_2 Ref_chroms tmp
echo "G-Anchor's preprocessing stage is finished!"
echo "Your new HCE fasta sequences (calculated based on the new reference) are in FINAL_FASTA/ folder. The HCE coordinates (.bed format) are in HCE_FASTA_coords/ folder"
echo "Don't forget to check the logFile"
